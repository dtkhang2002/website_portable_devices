package controller;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import dao.ListProductDAO;
import model.Product;

/**
 * Servlet implementation class AddProductController
 */
@WebServlet("/AddProductController")
public class AddProductController extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public AddProductController() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		PrintWriter out = response.getWriter();
		// TODO Auto-generated method stub
		response.setContentType("text/html;charset=UTF-8");
		request.setCharacterEncoding("utf-8");// vietnamese
		// regex
		String regex = "[a-zA-Z0-9_!@#$%^&*]+";
		try {
			ListProductDAO prd = new ListProductDAO();
			// get input value
			String name = request.getParameter("name");
			String des = request.getParameter("description");
			float price = Float.parseFloat(request.getParameter("price"));
			String src = request.getParameter("imgsrc");
			String type = request.getParameter("type");
			String brand = request.getParameter("brand");
			if(!brand.matches(regex)) {
				RequestDispatcher rd = request.getRequestDispatcher("/addproduct.jsp");
				out.println("<font color = 'red'>Invalid input.</font>");
				rd.include(request, response);
			}else {
				Product product = new Product(name, des, price, src, type, brand);
				prd.AddNewProduct(product);
				RequestDispatcher rd = request.getRequestDispatcher("/admin.jsp");
				rd.forward(request, response);
			}
		}catch(Exception e) {
			e.printStackTrace();
		}
	}

}
