package controller;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import dao.AccountDAO;
import model.Account;

/**
 * Servlet implementation class SignUpController
 */
@WebServlet("/SignUpController")
public class SignUpController extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public SignUpController() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.setContentType("text/html;charset=UTF-8");
		request.setCharacterEncoding("utf-8");// vietnamese
		// regex
		String regexMail = "^[A-Z0-9_a-z]+@[A-Z0-9\\.a-z]+\\.[A-Za-z]{2,6}$";
		String regex = "[a-zA-Z0-9_!@#$%^&*]+";

		try {
			// get input value
			String email = request.getParameter("email");
			String password = request.getParameter("password");
			String repeat = request.getParameter("repeat");
			// sign in by customer set role = 0; role =1 if signin by admin
			int role = 0;
			String username = request.getParameter("username");
			String address = request.getParameter("address");
			String phone = request.getParameter("phone");

			// create new accountDAO and session
			HttpSession session = request.getSession(true);
			AccountDAO ac = new AccountDAO();
			// check userID and password regex
			if (!email.matches(regexMail) || !password.matches(regex)) {
				// if not match, print error and load login page again
				RequestDispatcher rd = request.getRequestDispatcher("/signup.jsp");
				response.getWriter().println("<font color='red'>Invalid mail or password regex</font>");
				rd.include(request, response);
			} else if (!password.equals(repeat)) {
				RequestDispatcher rd = request.getRequestDispatcher("/signup.jsp");
				response.getWriter().println("<font color='red'>Password do not match</font>");
				rd.include(request, response);
			} else {
				Account account = new Account(email, password, role, username, address, phone);
				if (ac.exists(email)) {
					RequestDispatcher rd = request.getRequestDispatcher("/signup.jsp");
					response.getWriter().println("<font color='red'>Account existed</font>");
					rd.include(request, response);
				} else {
					session.setAttribute("accountSign", account);
					ac.signup(account);
					RequestDispatcher rd = request.getRequestDispatcher("/login.jsp");
					response.getWriter().println("<font color='green'>Account created successfully</font>");
					rd.forward(request, response);
				}
			}
		} catch (Exception ex) {
			response.getWriter().println(ex);
		}

	}

}
