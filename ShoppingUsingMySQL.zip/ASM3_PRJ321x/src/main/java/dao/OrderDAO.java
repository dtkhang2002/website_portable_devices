package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import context.DBContext;
import model.Cart;
import model.Orders;
import model.Product;
import model.ProductOrders;

public class OrderDAO {
	// insert into Order DB and Order_Detail DB
	public void insertOrder(Orders order, Cart cart) throws Exception {
		// connect to the database
		DBContext db = new DBContext();
		Connection con = db.getConnection();
		// update orderID
		int orderID = 1;
		// sql query
		String sql = "select * from Orders";
		String sql1 = "Insert into Orders values(?,?,?,?,?,?)";
		PreparedStatement stmt = con.prepareStatement(sql);
		ResultSet rs = stmt.executeQuery();
		while(rs.next()) {
			orderID++;
		}
		// take info for Order db
		PreparedStatement stmt1 = con.prepareStatement(sql1);
		stmt1.setString(1, order.getUserMail());
		stmt1.setInt(2, orderID);
		stmt1.setInt(3, order.getStatus());
		stmt1.setDate(4, order.getOrderDate());
		stmt1.setString(5, order.getDiscount());
		stmt1.setString(6, order.getAddress());
		stmt1.executeUpdate();
		stmt1.close();
		// take info for Order_detail db
		String sql2 = "Insert into Orders_detail values(?,?,?,?)";
		PreparedStatement stmt2 = con.prepareStatement(sql2);
		List<Product> cartList = cart.getItems();
		// take all the info in a loop into the db
		for(Product x: cartList) {
			float money = x.getPrice() * x.getNumber();
			stmt2.setInt(1, orderID);
			stmt2.setInt(2, x.getId());
			stmt2.setInt(3, x.getNumber());
			stmt2.setFloat(4, money);
			stmt2.executeUpdate();
		}
		stmt.close();
	}
	// show user order details
	public List<ProductOrders> getUserProduct(String mail) throws Exception{
		// create a list to store the infor of user detail
		List<ProductOrders> order = new ArrayList<ProductOrders>();
		// create a list to store the orderID from Order db
		List<Integer> orderID = new ArrayList<>();
		// connect to the database
		DBContext db = new DBContext();
		Connection con = db.getConnection();
		// sql query
		String sql = "select * from Orders";
		PreparedStatement stmt = con.prepareStatement(sql);
		// execute query
		ResultSet rs = stmt.executeQuery();
		// find the usermail with their order_id
		while(rs.next()) {
			String email = rs.getString(1);
			if(email.equalsIgnoreCase(mail)) {
				int orID = rs.getInt(2);
				orderID.add(orID);
			}
		}
		stmt.close();
		
		// get product info of user from order_detail
		// sql query
		String sql1 = "select * from Orders_detail";
		PreparedStatement stmt1 = con.prepareStatement(sql1);
		rs = stmt1.executeQuery();
		while(rs.next()) {
			for(int x: orderID) {
				// check if the id product of user from order db is equal to the id 
				if(x == rs.getInt(1)) {
					int productID = rs.getInt(2);
					Product prget = new ListProductDAO().getProduct(productID);
					String name = prget.getName();
					float money = prget.getPrice() * rs.getInt(3);
					ProductOrders po = new ProductOrders(rs.getInt(1), rs.getInt(2), rs.getInt(3), name, money);
					order.add(po);
				}
			}
		}
		stmt1.close();
		return order;
	}
	// show orders from user
	public List<Orders> showOrders() throws Exception{
		List<Orders> order = new ArrayList<Orders>();
		// connect to the database
		DBContext db = new DBContext();
		Connection con = db.getConnection();
		// sql query
		String sql = "select * from Orders";
		// execute query
		PreparedStatement stmt = con.prepareStatement(sql);
		ResultSet rs = stmt.executeQuery();
		while(rs.next()) {
			order.add(new Orders(rs.getInt(2), rs.getDate(4), rs.getString(6), rs.getString(1), rs.getString(5)));
		}
		stmt.close();
		return order;
	}
	// show orders detail from bills of user
	public List<ProductOrders> showOrderDetails() throws Exception{
		List<ProductOrders> order = new ArrayList<ProductOrders>();
		List<Integer> orderID = new ArrayList<Integer>();
		// connect to the database
		DBContext db = new DBContext();
		Connection con = db.getConnection();
		// sql query
		String sql = "select * from Orders";
		PreparedStatement stmt = con.prepareStatement(sql);
		// execute query
		ResultSet rs = stmt.executeQuery();
		while (rs.next()) {
			int orID = rs.getInt(2);
			orderID.add(orID);
		}
		stmt.close();
		// get product infor from order detail db
		// sql query
		String sql1 = "select * from Orders_detail";
		PreparedStatement stmt1 = con.prepareStatement(sql1);
		rs = stmt1.executeQuery();
		while(rs.next()) {
			for(int x: orderID) {
				// check if the id product of user from order db is equal to the id 
				if(x == rs.getInt(1)) {
					int productID = rs.getInt(2);
					Product prget = new ListProductDAO().getProduct(productID);
					String name = prget.getName();
					float money = prget.getPrice() * rs.getInt(3);
					ProductOrders po = new ProductOrders(rs.getInt(1), rs.getInt(2), rs.getInt(3), name, money);
					order.add(po);
				}
			}
		}
		stmt1.close();
		return order;
	}
}
