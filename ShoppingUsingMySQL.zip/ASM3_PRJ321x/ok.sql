create database Shopping
use Shopping
drop table `products`
create table Account
(
user_mail varchar(100) not null primary key,
password varchar(64) not null,
account_role int not null,
user_name nvarchar(50) not null,
user_address nvarchar(255) not null,
user_phone varchar(10) not null
)

create table Orders
(
user_mail varchar(100) not null,
order_id int not null primary key,
order_status int not null,
order_date date not null,
order_discount_code varchar(8) null,
order_address nvarchar(255) not null
)

create table Products
(
product_id int NOT NULL AUTO_INCREMENT,
product_name nvarchar(100) not null,
product_des nvarchar(255) not null,
product_price float not null,
product_img_source varchar(255) not null,
product_type varchar(100) not null,
product_brand varchar(100) not null,
Primary key(product_id)
)

create table Orders_detail
(
order_id int not null,
product_id int not null,
amount_product int not null,
price_product float not null,
Constraint PK_OP primary key (order_id, product_id),
Constraint FK_O foreign key (order_id) references Orders(order_id),
Constraint FK_P foreign key (product_id) references Products(product_id)
)

insert into Account values
('duongdt@fpt.com.vn', '123', 1, 'Đinh Tùng Dương', 'Đại học FPT', '0765870407')
ALTER TABLE Products AUTO_INCREMENT=1;
insert into Products(product_name, product_des, product_price, product_img_source, product_type, product_brand) values
('iPhone 11', 'Chip: Apple A13 Bionic', 44.44, 'https://cdn.tgdd.vn/Products/Images/42/210644/iphone-11-trang-200x200.jpg', 'cellphone', 'apple')

delete from Orders_detail where product_id = 1; delete from Products where product_id = 1; select * from Products; ALTER TABLE Products AUTO_INCREMENT=1;