 package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import context.DBContext;
import model.Product;

public class ListProductDAO {
	// get Product by id
	public Product getProduct(int productID) throws Exception {
		Product prg = new Product();
		// connect to the database
		DBContext db = new DBContext();
		Connection con = db.getConnection();
		// sql query
		String sql = "select * from Products";
		// execute query
		PreparedStatement stmt = con.prepareStatement(sql);
		ResultSet rs = stmt.executeQuery();
		while(rs.next()) {
			int find = rs.getInt(1);
			// check if id is equals to 0 or not
			if(productID != 0) {
				// if not, check if the ID of product is equal to the ID of product in DB
				if(find == productID) {
					prg = new Product(rs.getInt(1), rs.getString(2), rs.getString(3), rs.getFloat(4), rs.getString(5), rs.getString(6), rs.getString(7));
				}
			}else {
				prg = null;
			}
		}
		stmt.close();
		return prg;
	}
	
	// delete products
	public void DeleteProducts(int id) throws Exception {
		//connect to the db
		DBContext db = new DBContext();
		Connection con = db.getConnection();
		// sql query
		//String sql = "delete from Orders_detail where product_id = ?; delete from Products where product_id = ?; select * from Products; DBCC CHECKIDENT (Products, RESEED, 0)"; sql server
		// mysql
		String sql = "delete from Orders_detail where product_id = ?";
		String sql1 = "delete from Products where product_id = ?";
		String sql2 = "select * from Products";
		String sql3 = "ALTER TABLE Products AUTO_INCREMENT=1";
		PreparedStatement stmt  = con.prepareStatement(sql);
		PreparedStatement stmt1  = con.prepareStatement(sql1);
		PreparedStatement stmt2  = con.prepareStatement(sql2);
		PreparedStatement stmt3  = con.prepareStatement(sql3);
		stmt.setInt(1, id);
		stmt1.setInt(1, id);
		stmt.executeUpdate();
		stmt1.executeUpdate();
		stmt2.execute();
		stmt3.execute();
		stmt.close();
		stmt1.close();
		stmt2.close();
		stmt3.close();
	}
	// update products
	public void UpdateProducts(Product product) throws Exception {
		//connect to the db
		DBContext db = new DBContext();
		Connection con = db.getConnection();
		// sql
		String sql = "Update Products set product_name = ?, product_des = ?, product_price = ?, product_img_source = ?, product_type = ?, product_brand = ? where product_id = ?";
		PreparedStatement stmt  = con.prepareStatement(sql);
		stmt.setString(1, product.getName());
		stmt.setString(2, product.getDescription());
		stmt.setFloat(3, product.getPrice());
		stmt.setString(4, product.getSrc());
		stmt.setString(5, product.getType());
		stmt.setString(6, product.getBrand());
		stmt.setInt(7, product.getId());
		stmt.executeUpdate();
		stmt.close();
	}
	// add new product
	public void AddNewProduct(Product product) throws Exception {
		//connect to the db
		DBContext db = new DBContext();
		Connection con = db.getConnection();
		// sql
		//String sql = "Insert into Products values(?, ?, ?, ?, ?, ?)"; sql server
		String sql = "insert into Products(product_name, product_des, product_price, product_img_source, product_type, product_brand) values(?, ?, ?, ?, ?, ?)";// mysql
		PreparedStatement stmt = con.prepareStatement(sql);
		stmt.setString(1, product.getName());
		stmt.setString(2, product.getDescription());
		stmt.setFloat(3, product.getPrice());
		stmt.setString(4, product.getSrc());
		stmt.setString(5, product.getType());
		stmt.setString(6, product.getBrand());
		
		stmt.execute();
		stmt.close();
	}
	// get total number of product
		public int getTotalProduct() throws Exception {
			// connect to database
			DBContext db = new DBContext();
			Connection con = db.getConnection();
			// sql
			String query = "Select count(*) from Products";
			PreparedStatement stmt = con.prepareStatement(query);
			ResultSet rs = stmt.executeQuery();
			while(rs.next()) {
				return rs.getInt(1);
			}
			stmt.close();
			return 0;
		}
		// paging Product
		public List<Product> pagingAccount(int id) throws Exception{
			// creat a list
			List<Product> mylist = new ArrayList<Product>();
			// connect to database
			DBContext db = new DBContext();
			Connection con = db.getConnection();
			//sql query
			String sql = "select * from Products order by product_id LIMIT 3 OFFSET ?";
			PreparedStatement stmt = con.prepareStatement(sql);
			stmt.setInt(1, (id-1)*3);
			ResultSet rs = stmt.executeQuery();
			while(rs.next()) {
				mylist.add(new Product(rs.getInt(1), rs.getString(2), rs.getString(3), rs.getFloat(4), rs.getString(5), rs.getString(6), rs.getString(7)));
			}
			stmt.close();
			return mylist;
		}
		// classify brand
		public List<Product> classifyProduct() throws Exception{
			// create a list
			List<Product> mylist = new ArrayList<Product>();
			// connect to database
			DBContext db = new DBContext();
			Connection con = db.getConnection();
			//sql query
			String sql = "SELECT distinct product_brand FROM shopping.products";
			PreparedStatement stmt = con.prepareStatement(sql);
			ResultSet rs = stmt.executeQuery();
			while(rs.next()) {
				mylist.add(new Product(rs.getString(1)));
			}
			stmt.close();
			return mylist;
		}
		// Search product by brand and paging
		public List<Product> getProductByBrand(String brand, int id) throws Exception{
			// create a list
			List<Product> mylist = new ArrayList<Product>();
			// connect to database
			DBContext db = new DBContext();
			Connection con = db.getConnection();
			//sql query
			String sql = "select * from Products where product_brand = ? order by product_id LIMIT 3 OFFSET ?";
			PreparedStatement stmt = con.prepareStatement(sql);
			stmt.setString(1, brand);
			stmt.setInt(2, (id-1)*3);
			ResultSet rs = stmt.executeQuery();
			while(rs.next()) {
				mylist.add(new Product(rs.getInt(1), rs.getString(2), rs.getString(3), rs.getFloat(4), rs.getString(5), rs.getString(6), rs.getString(7)));
			}
			stmt.close();
			return mylist;
		}
		
		// count the number of result searched by brand
		public int countSearch(String brand) throws Exception{
			DBContext db = new DBContext();
			Connection con = db.getConnection();
			// sql query
			String sql = "Select count(*) from Products where product_brand = ?";
			PreparedStatement stmt = con.prepareStatement(sql);
			stmt.setString(1, brand);
			ResultSet rs = stmt.executeQuery();
			while(rs.next()) {
				return rs.getInt(1);
			}
			stmt.close();
			return 0;
		}
		
		// count the number of result searched by name
		public int countNameSearch(String name) throws Exception{
			DBContext db = new DBContext();
			Connection con = db.getConnection();
			// sql query
			String sql = "Select count(*) from Products where product_name like ?";
			PreparedStatement stmt = con.prepareStatement(sql);
			stmt.setString(1, "%" + name + "%");
			ResultSet rs = stmt.executeQuery();
			while(rs.next()) {
				return rs.getInt(1);
			}
			return 0;
		}
		// search by name
		public List<Product> search(String name, int id) throws Exception{
			// creat a list
			List<Product> mylist = new ArrayList<Product>();
			// connect to database
			DBContext db = new DBContext();
			Connection con = db.getConnection();
			//sql query
			String sql = "select * from Products where product_name like ? order by product_id LIMIT 3 OFFSET ?";
			PreparedStatement stmt = con.prepareStatement(sql);
			stmt.setString(1, "%" + name + "%");
			stmt.setInt(2, (id-1)*3);
			ResultSet rs = stmt.executeQuery();
			while(rs.next()) {
				mylist.add(new Product(rs.getInt(1), rs.getString(2), rs.getString(3), rs.getFloat(4), rs.getString(5), rs.getString(6), rs.getString(7)));
			}
			stmt.close();
			return mylist;
		}
		
}
