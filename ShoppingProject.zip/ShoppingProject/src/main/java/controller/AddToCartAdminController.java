package controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import dao.ListProductDAO;
import model.Account;
import model.Cart;
import model.Product;

/**
 * Servlet implementation class AddToCartAdminController
 */
@WebServlet("/AddToCartAdminController")
public class AddToCartAdminController extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public AddToCartAdminController() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.setContentType("text/html;charset=UTF-8");
		request.setCharacterEncoding("utf-8");// vietnamese
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		PrintWriter out = response.getWriter();
		response.setContentType("text/html;charset=UTF-8");
		request.setCharacterEncoding("utf-8");// vietnamese
		// create a session to manage the webpage
		HttpSession session = request.getSession(true);
		// Get product from jsp
		String idget = request.getParameter("id");
		int id = Integer.parseInt(idget);
		// create a new list
		List<Product> cartList = new ArrayList<Product>();
		// create cart session
		if(session.getAttribute("cart") == null) {
			session.setAttribute("cart", new Cart());
		}
		Cart c = (Cart) session.getAttribute("cart");
		// create get account for user to manage
		if(session.getAttribute("account") != null) {
			Account acc = (Account) session.getAttribute("account");
			String mail = acc.getUsr();
			String address = acc.getAddress();
			String phone = acc.getPhone();
			session.setAttribute("mail", mail);
			session.setAttribute("address", address);
			session.setAttribute("phone", phone);
		}
		// show information of the product if button showInfor is clicked
		if(request.getParameter("showInfo") != null) {
			try {
				request.setAttribute("productDetail", new ListProductDAO().getProduct(id));// get ID of product by click to the product
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			RequestDispatcher rd = request.getRequestDispatcher("/product_admin_info.jsp");
			rd.forward(request, response);
		}
		// delete products if button delete is clicked
		if(request.getParameter("btnDelete") != null) {
			ListProductDAO pr = new ListProductDAO();
			try {
				pr.DeleteProducts(id);
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			RequestDispatcher rd = request.getRequestDispatcher("HomeAdminController");
			rd.forward(request, response);
		}
		// update products if button update is clicked
		if(request.getParameter("btnUpdate") != null) {
			ListProductDAO lst = new ListProductDAO();
			try {
				Product pro = lst.getProduct(id);
				request.setAttribute("pr", pro);
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			RequestDispatcher rd = request.getRequestDispatcher("/update.jsp");
			rd.forward(request, response);
		}
		// show information of the products when addtocart is clicked
		if(request.getParameter("btnAdd") != null) {
			if(session.getAttribute("cart") == null) {
				session.setAttribute("cart", new Cart());
			}
			// get Product added by ID
			try {
				Product product = new ListProductDAO().getProduct(id);// get ID of product by click to the product
				c.add(product);// add to cart and store in this cart
				// update cart
				cartList = c.getItems();// getItems after add
				double amount = c.getAmount();
				// set session
				session.setAttribute("amount", amount);
				session.setAttribute("cartList", cartList);
				// send to the cart page
				RequestDispatcher rd = request.getRequestDispatcher("/cart_admin.jsp");
				rd.forward(request, response);
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
			// if button remove is clicked
		}else if(request.getParameter("btnRemove") != null) {
			try {
				Product pro = new ListProductDAO().getProduct(id);
				c.remove(pro);// remove product in cart
				// update cart
				cartList = c.getItems();// getItems after remove
				double amount = c.getAmount();
				// set session
				session.setAttribute("amount", amount);
				session.setAttribute("cartList", cartList);
				// send to the cart page
				RequestDispatcher rd = request.getRequestDispatcher("/cart_admin.jsp");
				rd.forward(request, response);
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			// check if btnDel is clicked
		}else if(request.getParameter("btnDel") != null) {
			try {
				Product pro = new ListProductDAO().getProduct(id);
				c.delete(pro);// delete all the product in cart
				// update cart
				cartList = c.getItems();// get all the products after delete all
				double amount = c.getAmount();
				// set session
				session.setAttribute("amount", amount);
				session.setAttribute("cartList", cartList);
				if(amount == 0.0) {
					RequestDispatcher rd = request.getRequestDispatcher("/cart_admin.jsp");
					out.println("<font color = 'red'>Invalid items.</font>");
					rd.include(request, response);
				}
				// send to the cart page
				RequestDispatcher rd = request.getRequestDispatcher("/cart_admin.jsp");
				rd.forward(request, response);
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}

}
