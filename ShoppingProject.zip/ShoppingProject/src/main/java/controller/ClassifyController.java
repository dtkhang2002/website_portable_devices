package controller;

import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import dao.ListProductDAO;
import model.Product;

/**
 * Servlet implementation class ClassifyController
 */
@WebServlet("/ClassifyController")
public class ClassifyController extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public ClassifyController() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		response.setContentType("text/html;charset=UTF-8");
		request.setCharacterEncoding("utf-8");// vietnamese
		// TODO Auto-generated method stub
		try {
			ListProductDAO dao = new ListProductDAO();
			String brand = request.getParameter("brand");
			int count = dao.countSearch(brand);
			//System.out.println(count);
			int endPage = count/3;
			if(count%3!=0) {
				endPage++;
			}
			String indexPage = request.getParameter("index");
			if(indexPage == null) {
				indexPage = "1";
			}
			int index = Integer.parseInt(indexPage);
			List<Product> list = dao.getProductByBrand(brand, index);
			List<Product> listC = dao.classifyProduct();
			request.setAttribute("listC", listC);
			request.setAttribute("myList", list);
			request.setAttribute("endP", endPage);
			request.setAttribute("tag", count);
			request.setAttribute("brand", brand);
			request.getRequestDispatcher("/search.jsp").forward(request, response);
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}

	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
