package context;

import dao.AccountDAO;

public class TestSQL {

	public static void main(String[] args) throws Exception {
		// TODO Auto-generated method stub
		AccountDAO dao = new AccountDAO();
		System.out.println(dao.getName("duongdt@fpt.com.vn"));
	}

}
