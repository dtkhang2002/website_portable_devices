package context;

import java.util.List;

import dao.AccountDAO;
import dao.ListProductDAO;
import model.Product;

public class TestSQL {

	public static void main(String[] args) throws Exception {
		// TODO Auto-generated method stub
		AccountDAO dao = new AccountDAO();
		System.out.println(dao.getName("lamtotet2015@gmail.com"));
	}

}
