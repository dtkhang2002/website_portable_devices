package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import context.DBContext;
import model.Product;

public class ListProductDAO {
	// search by name
	public List<Product> search(String productName) throws Exception{
		// creat a list
		List<Product> mylist = new ArrayList<Product>();
		// connect to the database
		DBContext db = new DBContext();
		Connection con = db.getConnection();
		// sql query
		String sql = "select * from Products";
		PreparedStatement stmt = con.prepareStatement(sql);
		// execute query
		ResultSet rs = stmt.executeQuery();
		while(rs.next()) {
			// if not empty, find the product
			if(!productName.isEmpty()) {
				String name = rs.getString(2);
				if(productName.equalsIgnoreCase(name)) {
					Product prf = new Product(rs.getInt(1), rs.getString(2), rs.getString(3), rs.getFloat(4), rs.getString(5), rs.getString(6), rs.getString(7));
					mylist.add(prf);
				}
			}else {
				// if empty, show all the products
				Product pr = new Product(rs.getInt(1), rs.getString(2), rs.getString(3), rs.getFloat(4), rs.getString(5), rs.getString(6), rs.getString(7));
				mylist.add(pr);
			}
		}
		stmt.close();
		return mylist;
	}
	// get Product by id
	public Product getProduct(int productID) throws Exception {
		Product prg = new Product();
		// connect to the database
		DBContext db = new DBContext();
		Connection con = db.getConnection();
		// sql query
		String sql = "select * from Products";
		// execute query
		PreparedStatement stmt = con.prepareStatement(sql);
		ResultSet rs = stmt.executeQuery();
		while(rs.next()) {
			int find = rs.getInt(1);
			// check if id is equals to 0 or not
			if(productID != 0) {
				// if not, check if the ID of product is equal to the ID of product in DB
				if(find == productID) {
					prg = new Product(rs.getInt(1), rs.getString(2), rs.getString(3), rs.getFloat(4), rs.getString(5), rs.getString(6), rs.getString(7));
				}
			}else {
				prg = null;
			}
		}
		stmt.close();
		return prg;
	}
	
	// delete products
	public void DeleteProducts(int id) throws Exception {
		//connect to the db
		DBContext db = new DBContext();
		Connection con = db.getConnection();
		// sql query
		String sql = "delete from Orders_detail where product_id = ? delete from Products where product_id = ? select * from Products; DBCC CHECKIDENT (Products, RESEED, 0)";
		PreparedStatement stmt  = con.prepareStatement(sql);
		stmt.setInt(1, id);
		stmt.setInt(2, id);
		stmt.executeUpdate();
		stmt.close();
	}
	// update products
	public void UpdateProducts(Product product) throws Exception {
		//connect to the db
		DBContext db = new DBContext();
		Connection con = db.getConnection();
		// sql
		String sql = "Update Products set product_name = ?, product_des = ?, product_price = ?, product_img_source = ?, product_type = ?, product_brand = ? where product_id = ?";
		PreparedStatement stmt  = con.prepareStatement(sql);
		stmt.setString(1, product.getName());
		stmt.setString(2, product.getDescription());
		stmt.setFloat(3, product.getPrice());
		stmt.setString(4, product.getSrc());
		stmt.setString(5, product.getType());
		stmt.setString(6, product.getBrand());
		stmt.setInt(7, product.getId());
		stmt.executeUpdate();
		stmt.close();
	}
	// add new product
	public void AddNewProduct(Product product) throws Exception {
		//connect to the db
		DBContext db = new DBContext();
		Connection con = db.getConnection();
		// sql
		String sql = "Insert into Products values(?, ?, ?, ?, ?, ?)";
		PreparedStatement stmt = con.prepareStatement(sql);
		stmt.setString(1, product.getName());
		stmt.setString(2, product.getDescription());
		stmt.setFloat(3, product.getPrice());
		stmt.setString(4, product.getSrc());
		stmt.setString(5, product.getType());
		stmt.setString(6, product.getBrand());
		
		stmt.execute();
		stmt.close();
	}
}
