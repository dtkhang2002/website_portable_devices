package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import context.DBContext;
import model.Account;

public class AccountDAO {
	// Login
	public boolean login(String email, String password) throws Exception {
		//connect to the db
		DBContext db = new DBContext();
		Connection con = db.getConnection();
		// sql query
		String sql = "Select count(*) as count from Account where user_mail=? and password=?";
		PreparedStatement stmt = con.prepareStatement(sql);
		stmt.setString(1, email);
		stmt.setString(2, password);
		// execute query
		ResultSet rs = stmt.executeQuery();
		int count = 0;
		if(rs.next()) {
			count = rs.getInt("count");
		}
		rs.close();
		if(count == 0) {
			return false;
		}else {
			return true;
		}
	}
	// check role (1: administrator, 0: customer)
	public boolean checkRole(String email) throws Exception {
		boolean ok = false;
		// connect to the db
		DBContext db = new DBContext();
		Connection con = db.getConnection();
		// sql query
		String sql = "select * from Account";
		PreparedStatement stmt = con.prepareStatement(sql);
		// execute query
		ResultSet rs = stmt.executeQuery();
		while(rs.next()) {
			// get email
			String remail = rs.getString(1);
			// check role
			if(remail.equalsIgnoreCase(email) && rs.getInt(3) == 1) {
				ok = true;
			}
		}
		stmt.close();
		return ok;
	}
	// check if the account existed in the database or not
	public boolean exists(String email) throws Exception {
		// connect to the Database
		DBContext db = new DBContext();
		Connection con = db.getConnection();
		// sql query
		String sql = "select count(*) as count from Account where user_mail = ?";
		PreparedStatement stmt = con.prepareStatement(sql);
		stmt.setString(1, email);
		// execute query
		ResultSet rs = stmt.executeQuery();
		int count = 0;
		if(rs.next()) {
			count = rs.getInt("count");
		}
		rs.close();
		if(count == 0) {
			return false;
		}else { 
			return true;
		}
	}
	// sign up
	public void signup(Account account) throws Exception {
		// connect to the database
		DBContext db = new DBContext();
		Connection con = db.getConnection();
		// sql query
		String sql = "insert into Account (user_mail, password, account_role, user_name, user_address, user_phone) values(?,?,?,?,?,?)";
		PreparedStatement stmt = con.prepareStatement(sql);
		stmt.setString(1, account.getUsr());
		stmt.setString(2, account.getPwd());
		stmt.setInt(3, account.getRole());
		stmt.setString(4, account.getName());
		stmt.setString(5, account.getAddress());
		stmt.setString(6, account.getPhone());
		
		stmt.execute();
		stmt.close();
	}
	// get all the account in the db for admin
	public List<Account> getAccountAdmin() throws Exception{
		// make a list to store all the account
		List<Account> listAcc = new ArrayList<Account>();
		// connect to the database
		DBContext db = new DBContext();
		Connection con = db.getConnection();
		// sql query
		String sql = "select * from Account";
		PreparedStatement stmt = con.prepareStatement(sql);
		// execute query
		ResultSet rs = stmt.executeQuery();
		while(rs.next()) {
			listAcc.add(new Account(rs.getString(1), rs.getString(2), rs.getInt(3), rs.getString(4), rs.getString(5), rs.getString(6)));
		}
		stmt.close();
		return listAcc;
	}
	// delete account
	public void deleteAccount(String email) throws Exception {
		// connect to the database
		DBContext db = new DBContext();
		Connection con = db.getConnection();
		String sql = "delete from Account where user_mail = ?; select * from Account";
		PreparedStatement stmt = con.prepareStatement(sql);
		stmt.setString(1, email);
		stmt.executeUpdate();
		stmt.close();
		
	}
}
