package context;

import java.util.ArrayList;
import java.util.List;

import dao.ListProductDAO;
import model.Product;

public class CheckSQL {

	public static void main(String[] args) throws Exception {
		// TODO Auto-generated method stub
		String regexWord = "[a-zA-Z][a-zA-Z ]+";
		String a = "abcyz";
		if(a.matches(regexWord)) {
			System.out.println(1);
		}else {
			System.out.println(0);
		}
		
	}

}
