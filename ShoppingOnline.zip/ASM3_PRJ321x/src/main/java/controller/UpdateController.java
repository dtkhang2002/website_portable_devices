package controller;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import dao.ListProductDAO;
import model.Product;

/**
 * Servlet implementation class UpdateController
 */
@WebServlet("/UpdateController")
public class UpdateController extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public UpdateController() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		PrintWriter out = response.getWriter();
		// TODO Auto-generated method stub
		response.setContentType("text/html;charset=UTF-8");
		request.setCharacterEncoding("utf-8");
		// regex
		String regex = "[a-zA-Z0-9_!@#$%^&*]+";
		// collect the data from form
		int id = Integer.parseInt(request.getParameter("id"));
		String name = request.getParameter("name");
		String des = request.getParameter("description");
		float price = Float.parseFloat(request.getParameter("price"));
		String src = request.getParameter("imgsrc");
		String type = request.getParameter("type");
		String brand = request.getParameter("brand");
		if(!type.matches(regex) || !brand.matches(regex)) {
			RequestDispatcher rd = request.getRequestDispatcher("/update.jsp");
			out.println("<font color = 'red'>Invalid input.</font>");
			rd.include(request, response);
		}else {
			// Update function
			ListProductDAO prd = new ListProductDAO();
			try {
				prd.UpdateProducts(new Product(id, name, des, price, src, type, brand));
				RequestDispatcher rd = request.getRequestDispatcher("HomeAdminController");
				rd.forward(request, response);
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}

}
