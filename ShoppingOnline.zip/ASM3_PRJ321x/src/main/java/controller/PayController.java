package controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Date;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import dao.OrderDAO;
import model.Cart;
import model.Orders;
import model.Product;

/**
 * Servlet implementation class PayController
 */
@WebServlet("/PayController")
public class PayController extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public PayController() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub
		PrintWriter out = response.getWriter();
		response.setContentType("text/html;charset=UTF-8");
		request.setCharacterEncoding("utf-8");// vietnamese
		// create session
		HttpSession session = request.getSession(true);
		// Working with db
		OrderDAO dao = new OrderDAO();
		// take order info
		if (session.getAttribute("cart") != null) {
			Cart c = (Cart) session.getAttribute("cart");
			List<Product> cartList = c.getItems();
			session.setAttribute("orderInfo", cartList);
				double priceall = c.getAmount();
				session.setAttribute("priceall", priceall);
				// date time today
				long millis = System.currentTimeMillis();
				Date date = new java.sql.Date(millis);
				// if account logged in, get it to fill in the blank
				String mail = "";
				if (session.getAttribute("account") != null) {
					mail = (String) session.getAttribute("mail");
				} else {
					mail = request.getParameter("mail");
				}
				String discount = request.getParameter("discount");
				String address = request.getParameter("address");
				if (cartList.isEmpty()) {
					RequestDispatcher rd = request.getRequestDispatcher("/cart.jsp");
					out.println("<font color = 'red'>Invalid items.</font>");
					rd.include(request, response);
				} else {
				// insert to the database
				Orders order = new Orders(date, address, mail, discount);
				try {
					dao.insertOrder(order, c);
					RequestDispatcher rd = request.getRequestDispatcher("cart_status.jsp");
					rd.forward(request, response);
				} catch (Exception e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		}
	}

}
